package net.oschina.j2cache.hibernate3;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class J2CacheRegionFactoryTest {

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testBuildCollectionRegion() throws Exception {

    }

    @Test
    public void testBuildEntityRegion() throws Exception {

    }

    @Test
    public void testBuildQueryResultsRegion() throws Exception {

    }

    @Test
    public void testBuildTimestampsRegion() throws Exception {

    }

    @Test
    public void testIsMinimalPutsEnabledByDefault() throws Exception {

    }

    @Test
    public void testNextTimestamp() throws Exception {

    }

    @Test
    public void testStart() throws Exception {

    }

    @Test
    public void testStop() throws Exception {

    }
}