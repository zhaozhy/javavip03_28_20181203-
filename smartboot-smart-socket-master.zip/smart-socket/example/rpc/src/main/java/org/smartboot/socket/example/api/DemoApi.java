package org.smartboot.socket.example.api;

/**
 * @author 三刀
 * @version V1.0 , 2018/7/1
 */
public interface DemoApi {

    String test(String name);

    int sum(int a, int b);
}
